<div class="layout-footer-body" style="text-align: center">
	<small class="copyright">Developed by Unacores Solutions Private Limited</small>
</div>