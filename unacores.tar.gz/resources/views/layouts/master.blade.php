<!DOCTYPE html>
<html lang="en">
@include('layouts/partials/head')
@yield('content')
@yield('custom-script')
</html>